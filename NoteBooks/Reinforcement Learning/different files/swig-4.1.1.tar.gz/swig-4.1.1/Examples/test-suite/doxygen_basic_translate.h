
/**
 * This file contains only doxygen comment without a declaration -
 * it should be ignored by SWIG and must not trigger syntax error.
 */
