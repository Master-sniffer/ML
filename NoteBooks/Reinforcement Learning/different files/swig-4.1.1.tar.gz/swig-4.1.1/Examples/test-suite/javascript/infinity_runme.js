var infinity = require("infinity");

infinity.initialise_MYINFINITY();
var my_infinity = infinity.INFINITY;
var ret_val = infinity.use_infinity(my_infinity);
