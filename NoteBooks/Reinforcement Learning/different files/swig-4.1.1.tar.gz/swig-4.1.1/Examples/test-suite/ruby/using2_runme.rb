#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'using2'

raise RuntimeError unless Using2.spam(37) == 37

