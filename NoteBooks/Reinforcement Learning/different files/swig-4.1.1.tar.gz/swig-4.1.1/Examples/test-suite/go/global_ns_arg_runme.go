package main

import . "swigtests/global_ns_arg"

func main() {
	Foo(1)
	Bar_fn()
}
