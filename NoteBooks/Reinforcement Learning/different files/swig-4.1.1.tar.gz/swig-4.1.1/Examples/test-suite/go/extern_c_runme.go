package main

import "swigtests/extern_c"

func main() {
	extern_c.RealFunction(2)
}
